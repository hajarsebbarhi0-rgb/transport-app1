import LoginScreen from './login';

export default function Index() {
  return <LoginScreen />;
}
